const mongoose = require('mongoose');
const OrderSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  items: [{ artwork: { type: mongoose.Schema.Types.ObjectId, ref: 'Artwork' }, price: Number }],
  amount: Number,
  currency: { type: String, default: 'usd' },
  stripeSessionId: String,
  status: { type: String, enum: ['created','paid','fulfilled'], default: 'created' },
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Order', OrderSchema);
