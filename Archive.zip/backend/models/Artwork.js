const mongoose = require('mongoose');
const ArtworkSchema = new mongoose.Schema({
  title: String,
  description: String,
  imageUrl: String,
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  price: Number,
  tags: [String],
  likes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  comments: [{ user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, text: String, createdAt: Date }],
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Artwork', ArtworkSchema);
