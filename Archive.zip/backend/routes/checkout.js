const express = require('express');
const router = express.Router();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const Order = require('../models/Order');
const Artwork = require('../models/Artwork');
const auth = require('../middleware/auth');

// Create a Checkout Session
router.post('/create-session', auth, async (req,res)=>{
  try{
    const { items, success_url, cancel_url } = req.body;
    if(!items || !Array.isArray(items) || items.length===0) return res.status(400).json({ msg: 'No items' });

    const line_items = [];
    let amount = 0;
    for(const it of items){
      // For safety, fetch artwork price from DB if artwork id provided
      if(it.artworkId){
        const art = await Artwork.findById(it.artworkId);
        if(!art) continue;
        const price = Math.round((art.price || 0) * 100);
        amount += price;
        line_items.push({
          price_data: {
            currency: 'usd',
            product_data: { name: art.title, description: art.description || '' },
            unit_amount: price
          },
          quantity: it.quantity || 1
        });
      } else {
        const price = Math.round((it.price || 0) * 100);
        amount += price * (it.quantity||1);
        line_items.push({
          price_data: {
            currency: 'usd',
            product_data: { name: it.name || 'Item' },
            unit_amount: price
          },
          quantity: it.quantity || 1
        });
      }
    }

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items,
      mode: 'payment',
      success_url: success_url || `${process.env.SUCCESS_URL || 'http://localhost:3000'}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: cancel_url || `${process.env.CANCEL_URL || 'http://localhost:3000'}/checkout/cancel`
    });

    // create order record (status: created)
    const order = new Order({ user: req.user.id, items: items.map(i=>({ artwork: i.artworkId, price: i.price || 0 })), amount: amount/100, stripeSessionId: session.id });
    await order.save();

    res.json({ url: session.url, sessionId: session.id });
  }catch(err){ console.error(err); res.status(500).json({ error: err.message });}
});

// webhook endpoint (raw body required). You must set STRIPE_WEBHOOK_SECRET in env and configure Stripe to call this URL.
router.post('/webhook', express.raw({type: 'application/json'}), async (req,res)=>{
  const sig = req.headers['stripe-signature'];
  let event;
  try{
    if(process.env.STRIPE_WEBHOOK_SECRET){
      event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
    } else {
      event = req.body; // insecure in dev
    }
  }catch(err){
    console.error('Webhook signature verification failed.', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if(event.type === 'checkout.session.completed'){
    const session = event.data.object;
    // fulfill the order: find by session.id and mark paid
    try{
      const order = await Order.findOne({ stripeSessionId: session.id });
      if(order){
        order.status = 'paid';
        await order.save();
      }
    }catch(e){ console.error('Order fulfill error', e); }
  }
  res.json({ received: true });
});

module.exports = router;
