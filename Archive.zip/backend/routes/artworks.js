const express = require('express');
const router = express.Router();
const multer = require('multer');
const Artwork = require('../models/Artwork');
const auth = require('../middleware/auth');

const storage = multer.diskStorage({
  destination: function (req, file, cb) { cb(null, 'uploads/'); },
  filename: function (req, file, cb) { cb(null, Date.now() + '-' + file.originalname); }
});
const upload = multer({ storage });

router.post('/', auth, upload.single('image'), async (req,res)=>{
  try{
    const { title, description, price, tags } = req.body;
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : req.body.imageBase64;
    const art = new Artwork({ title, description, imageUrl, owner: req.user.id, price, tags: tags ? tags.split(',').map(t=>t.trim()) : [] });
    await art.save();
    res.json(art);
  }catch(err){ console.error(err); res.status(500).send('Server error');}
});

router.get('/', async (req,res)=>{
  try{
    const q = req.query.q || '';
    const tag = req.query.tag;
    const filter = {};
    if(q) filter.title = new RegExp(q, 'i');
    if(tag) filter.tags = tag;
    const arts = await Artwork.find(filter).populate('owner','name').sort({ createdAt: -1 }).limit(200);
    res.json(arts);
  }catch(err){ console.error(err); res.status(500).send('Server error');}
});

router.post('/:id/like', auth, async (req,res)=>{
  try{
    const art = await Artwork.findById(req.params.id);
    if(!art) return res.status(404).send('Not found');
    const idx = art.likes.indexOf(req.user.id);
    if(idx===-1) art.likes.push(req.user.id); else art.likes.splice(idx,1);
    await art.save();
    res.json(art);
  }catch(err){ console.error(err); res.status(500).send('Server error');}
});

router.post('/:id/comment', auth, async (req,res)=>{
  try{
    const art = await Artwork.findById(req.params.id);
    if(!art) return res.status(404).send('Not found');
    art.comments.push({ user: req.user.id, text: req.body.text, createdAt: new Date() });
    await art.save();
    res.json(art);
  }catch(err){ console.error(err); res.status(500).send('Server error');}
});

module.exports = router;
