import React, { useEffect, useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import api from './api/apiClient';
import Gallery from './pages/Gallery';
import Auth from './pages/Auth';
import Checkout from './pages/Checkout';
import Header from './components/Header';

export default function App(){
  const [user, setUser] = useState(null);
  const [cart, setCart] = useState(() => JSON.parse(localStorage.getItem('abtp_cart')||'[]'));
  useEffect(()=>{ const t = localStorage.getItem('token'); if(t){ api.get('/users/me').then(r=>setUser(r.data)).catch(()=>{}); } },[]);
  useEffect(()=> localStorage.setItem('abtp_cart', JSON.stringify(cart)), [cart]);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      <Header user={user} />
      <main className="p-4">
        <Routes>
          <Route path="/" element={<Gallery />} />
          <Route path="/auth" element={<Auth setUser={setUser} />} />
          <Route path="/checkout" element={<Checkout cart={cart} />} />
        </Routes>
      </main>
    </div>
  )
}
