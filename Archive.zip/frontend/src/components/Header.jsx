import React from 'react';
import { Link } from 'react-router-dom';

export default function Header({user}){
  return (
    <header className="p-4 flex items-center justify-between bg-gradient-to-r from-yellow-500 via-pink-500 to-purple-600">
      <Link to="/" className="text-2xl font-extrabold">Art By The Pound</Link>
      <nav className="space-x-3">
        <Link to="/" className="px-3 py-1 bg-gray-800 rounded">Gallery</Link>
        <Link to="/auth" className="px-3 py-1 bg-gray-800 rounded">Login</Link>
      </nav>
    </header>
  )
}
