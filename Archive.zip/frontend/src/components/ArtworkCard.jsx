import React from 'react';
export default function ArtworkCard({art}){
  return (
    <div className="bg-gray-800 p-2 rounded shadow">
      <img src={art.imageUrl} alt={art.title} className="w-full h-40 object-cover rounded" />
      <div className="mt-2 flex justify-between items-center">
        <div>
          <div className="font-bold">{art.title}</div>
          <div className="text-xs text-gray-400">${art.price}</div>
        </div>
      </div>
    </div>
  )
}
