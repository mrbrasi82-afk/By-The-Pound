import React, { useEffect, useState } from 'react';
import api from '../api/apiClient';
import ArtworkCard from '../components/ArtworkCard';
import { Link } from 'react-router-dom';

export default function Gallery(){
  const [arts, setArts] = useState([]);
  useEffect(()=>{ api.get('/artworks').then(r=>setArts(r.data)).catch(()=>{}); },[]);
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Gallery</h1>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {arts.map(a=> <ArtworkCard key={a._id} art={a} />)}
      </div>
      <div className="mt-6"><Link to="/checkout" className="px-3 py-2 bg-yellow-500 text-black rounded">Go to Checkout (demo)</Link></div>
    </div>
  )
}
