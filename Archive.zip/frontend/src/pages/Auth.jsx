import React, { useState } from 'react';
import api from '../api/apiClient';
import { useNavigate } from 'react-router-dom';

export default function Auth({setUser}){
  const [email,setEmail]=useState(''); const [pass,setPass]=useState('');
  const nav = useNavigate();
  async function login(){ try{ const r=await api.post('/auth/login',{email,password:pass}); localStorage.setItem('token', r.data.token); const me=await api.get('/users/me'); setUser(me.data); nav('/'); }catch(e){ alert('Login failed'); } }
  return (
    <div className="max-w-md mx-auto bg-gray-800 p-6 rounded">
      <h2 className="text-xl font-bold mb-4">Login</h2>
      <input className="w-full p-2 mb-3 bg-gray-900 rounded" placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input type="password" className="w-full p-2 mb-3 bg-gray-900 rounded" placeholder="password" value={pass} onChange={e=>setPass(e.target.value)} />
      <button className="px-4 py-2 bg-indigo-600 rounded" onClick={login}>Login</button>
    </div>
  )
}
