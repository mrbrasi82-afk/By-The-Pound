import React from 'react';
import api from '../api/apiClient';

export default function Checkout({ cart }) {
  async function handleCheckout(){
    try{
      const resp = await api.post('/checkout/create-session', { items: cart });
      const url = resp.data.url;
      window.location.href = url;
    }catch(e){ console.error(e); alert('Checkout failed'); }
  }
  const total = (cart || []).reduce((s,i)=> s + ((i.price||0)*(i.quantity||1)), 0);
  return (
    <div className="max-w-2xl mx-auto bg-gray-800 p-6 rounded">
      <h2 className="text-xl font-bold mb-4">Checkout</h2>
      <div>Total: ${total.toFixed(2)}</div>
      <button className="mt-4 px-4 py-2 bg-green-600 rounded" onClick={handleCheckout}>Pay with Stripe</button>
    </div>
  );
}
